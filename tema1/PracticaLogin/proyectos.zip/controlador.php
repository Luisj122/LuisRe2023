<?php
session_start();
?>
<?php
  header("Content-Type: text/html; charset=UTF-8");
?>
<?php


if ($_POST) {

    if (isset($_POST['crearProyecto'])) {
        $nombre = $_POST['nombre'];
        $fechaInicio = $_POST['fechaInicio'];
        $fechaFinPrevisto = $_POST['fechaFinPrevisto'];
        $diasTranscurridos = $_POST['diasTranscurridos'];
        $porcentajeCompletado = $_POST['porcentajeCompletado'];
        $importancia = $_POST['importancia'];

        //Calculamos el id mayor
        $ids = array_column($_SESSION['proyectos'], 'id');
        $id = max($ids) + 1;

        array_push($_SESSION['proyectos'], ['id' => $id, 'nombre' => $nombre, 'diasTranscurridos' => $diasTranscurridos, 'fechaInicio' => $fechaInicio, 'fechaFinPrevisto' => $fechaFinPrevisto, 'porcentajeCompletado' => $porcentajeCompletado, 'importancia' => $importancia]);

        header("Location: proyectos.php");
    }

}

?>